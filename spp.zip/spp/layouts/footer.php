<div class="container pt-5">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-bottom mt-5">
    <div class="container">
  <a href="#" class="text-light">Copyright © 2023 SPP Dev</a>
  
  </div>
</nav>
</div>
<script src="js/jquery.slim.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>