<div class="container mt-5">
   <div class="row justify-content-center">
    <div class="col-6">
       <center> <img src="image/logo.png" alt=""> </center>
    <form method="post" action="admin.php?page=insertpetugas">
   <div class="form-group">
       <label> Username </label>
       <input type="text"  name="username" class="form-control" required> 
    </div> 
    <div class="form-group">
       <label> Password </label>
       <input type="password"  name="password" class="form-control" required> 
    </div>  
    <div class="form-group">
        <label> Nama Petugas </label>
        <input type="text" name="nama_petugas"  class="form-control" required>
    </div>
    <button type="submit" name="submit" class="btn btn-primary btn-sm"> Submit </button> 
   </form>
    </div>

   </div> 
</div> 