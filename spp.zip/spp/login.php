




<div class="container pt-5">
    <div class="row justify-content-center">
        <div class="col-4">
            <div class="card">
                <div class="class-header">
                    <center> 
                   Login Petugas
                            </center>
                        <center><img src="image/logo.png" alt="">
                            </center>
                    
                </div>
                <div class="card-body">
                    <form action="index.php?aksi=login" method="post">
                        
                        <div class="form-group">
                            <td> <b>Username</b> </td>
                            <input type="text" name="username" placeholder="username" class="form-control">
                            </div>
                       
                        <div class="form-group">
                            <td> <b>Password </b> </td>
                            <input type="password" name="password" placeholder="password" class="form-control">
                        </div>
                        <button name="login" class="btn btn-primary" id="loginB"> Login </button>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>