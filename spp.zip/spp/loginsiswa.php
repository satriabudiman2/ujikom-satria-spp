<div class="container pt-5">
    <div class="row justify-content-center">
        <div class="col-4">
            <div class="card">
                <div class="class-header">
                    <center> 
                   Login Siswa...
                            </center>
                        <center><img src="image/logo.png" alt="">
                            </center>
                    
                </div>
                <div class="card-body">
                    <form action="index.php?aksi=loginsiswa" method="post">
                        
                        <div class="form-group">
                            <input type="text" name="nisn" placeholder="nisn" class="form-control">
                            </div>
                        <div class="form-group">
                            <input type="text" name="nis" placeholder="nis" class="form-control">
                        </div>
                        <button name="login" class="btn btn-success" id="loginB" type="submit"> Login </button>
                    </form>
                </div>
               
            </div>
        </div>

    </div>
</div>